sap.ui.define([  
    "sap/ui/core/mvc/Controller",  
    "sap/m/MessageToast"  
], function (Controller, MessageToast) {  
    "use strict";  

    return Controller.extend("sapbtp.controller.SAP-BTP", {  

        onInit: function () {  
            // Initialization logic to set model if not done externally  
        },  

        onItemPress: function (oEvent) {  
            var oTile = oEvent.getSource();  
            var sTitle = oTile.getHeader();  
            var sAuthor = oTile.getSubheader();  
            MessageToast.show("You pressed: " + sTitle + " by " + sAuthor);  
        }  
    });  
});